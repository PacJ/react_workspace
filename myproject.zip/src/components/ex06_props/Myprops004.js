const Myprops004 = ({ name = '아무개', age = 10, loc = '서울' }) => {
  return (
    <div>
      <p>
        고객님 이름: {name} 나이: {age} 지역: {loc}
      </p>
    </div>
  );
};
export default Myprops004;
