import { Fragment } from 'react';

const MyJsx002 = () => {
  return (
    // <Fragment>
    <>
      <p>Start</p>
      <span>!!!</span>
    </>
    // </Fragment>
  );
};

export default MyJsx002;
