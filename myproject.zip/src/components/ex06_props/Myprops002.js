const Myprops002 = ({ name, age, loc }) => {
  return (
    <div>
      <p>
        고객님 이름: {name} 나이: {age} 지역: {loc}
      </p>
    </div>
  );
};
export default Myprops002;
